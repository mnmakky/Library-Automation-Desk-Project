-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 02, 2024 at 11:35 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `library_automation`
--

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE `book` (
  `bookid` int(10) NOT NULL,
  `barcode` int(11) NOT NULL,
  `bookcategoryid` int(10) NOT NULL,
  `bookname` varchar(255) NOT NULL,
  `callnumber` varchar(25) NOT NULL,
  `bookdescription` text NOT NULL,
  `bookimg` varchar(100) NOT NULL,
  `bookcost` float(10,2) NOT NULL,
  `author` varchar(25) NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`bookid`, `barcode`, `bookcategoryid`, `bookname`, `callnumber`, `bookdescription`, `bookimg`, `bookcost`, `author`, `status`) VALUES
(12, 123567, 10, 'Artificial Intelligence with Python: Your complete', 'WB 100 A345 2020', 'AI & Python', '2371651LtFs3LHCL._SX404_BO1,204,203,200_.jpg', 160.00, 'Alberto Artasanchez', 'Active'),
(13, 134567, 10, 'Python for Data Analysis: Data Wrangling with pand', 'WB 100 B432 2020', 'python', '66698125MPZTgbL._AC_UY218_.jpg', 260.00, 'Wes McKinney ', 'Active'),
(14, 567890, 10, 'Research Design: Quantitative, Qualitative, Mixed ', 'WB 100 B432 2020', 'research methodology', '1581081IfA1TlqNL._AC_UY218_.jpg', 250.00, 'John W. Creswell and J. D', 'Active'),
(15, 123568, 10, 'Hacking & Tor: The Complete Beginners Guide To Hac', 'WA 110 B432 2020', '', '795251xVrP6czML._AC_UY218_.jpg', 135.00, ' Jack Jones ', 'Active'),
(16, 567890, 10, 'Digging in the deep web: Exploring the dark side o', 'Wc 95 B432 2021', 'dark web', '17554411SEZW6VYL._AC_UY218_.jpg', 135.00, ' Ing Pierluigi Paganini', 'Active'),
(17, 897890, 10, 'Mathematics for Machine Learning', 'WC 95 B432 2021', 'mathematics computer', '2416391K7mHlgYtL._AC_UY218_.jpg', 200.00, 'Marc Peter Deisenroth', 'Active'),
(18, 567891, 10, 'Nanotechnology and Medicine (Next-Generation Medicine', 'WA 110 B432 2020', 'nanotechnology medicine', '205912904481rt3fOvrbL._AC_UY218_.jpg', 300.00, ' Don Nardo', 'Active'),
(19, 567890, 9, 'SQL for Data Analysis: Advanced Techniques for Tra', 'WA 100 S234 2001', '', '426431129714qourw99L._AC_UY218_.jpg', 300.00, 'Cathy Tanimura ', 'Active'),
(20, 123456, 9, 'A Short History of Medicine (Modern Library Chroni', 'WY 100 C234 2021', 'medicine', '5214912TzmdMGfL._AC_UY218_.jpg', 200.00, 'F. GonzÃ¡lez-Crussi', 'Active'),
(21, 123567, 10, 'Sabiston Textbook of Surgery: The Biological Basis', 'WD 125 N234 2022', 'surgery', '63sabiston.jpg', 200.00, 'Courtney M. Townsend', 'Active'),
(22, 123456, 10, 'The Regenerative Medicine Break Through', 'WX 95 B465 2021', 'medicine', '32012rege.jpg', 400.00, 'David Phipps', 'Active'),
(23, 12345, 10, 'Surgical Recall (Lippincott Connect)', 'WC 95 B432 2021', 'surgery', '8585surgicalrecall.jpg', 80.00, 'Lorne Blackbourne', 'Active'),
(24, 67843, 10, 'Sabiston Textbook of Surgery: The Biological Basis', 'Wc 95 B432 2021', 'surgery', '13710sabiston.jpg', 800.00, ' Courtney M. Townsend ', 'Active'),
(25, 67894, 10, 'Cleveland Clinic Illustrated Tips and Tricks in Co', 'WA 110 B432 2020', 'surgery', '17066colon.jpg', 200.00, ' Scott Steele', 'Active'),
(26, 34589, 10, 'Suture like a Surgeon: A Doctorâ€™s Guide to Surgi', 'WY 100 C234 2021', 'surgery', '14197suture.jpg', 200.00, 'M. MastenbjÃ¶rk', 'Active'),
(30, 87867, 10, 'Davidson,s\'\' Principles and Practice of Medicine 24th Edition', 'WA 100 S234 2020', 'gg', '1885417274CS.JPG', 600.00, '897891', 'Active'),
(31, 0, 10, 'Davidson\'s Principles and Practice of Medicine 24th Edition', 'WA 100 S234 2001', 'ddd', '94481231davidsons.jpg', 600.00, '897890', 'Active'),
(32, 0, 10, 'Davidson\'s Principles and Practice of Medicine 24th Edition', 'WA 100 S234 2001', 'gghfghf', '5889402davidsons.jpg', 600.00, '123568', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `bookcategory`
--

CREATE TABLE `bookcategory` (
  `bookcategoryid` int(10) NOT NULL,
  `bookcategory` varchar(50) NOT NULL,
  `bookdescription` text NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `bookcategory`
--

INSERT INTO `bookcategory` (`bookcategoryid`, `bookcategory`, `bookdescription`, `status`) VALUES
(9, 'Reference', ' book', 'Active'),
(10, 'Lending', ' Book', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `book_stock`
--

CREATE TABLE `book_stock` (
  `book_stock_id` int(10) NOT NULL,
  `bookid` int(10) NOT NULL,
  `branchid` int(10) NOT NULL,
  `purchasedate` date NOT NULL,
  `qty` int(10) NOT NULL,
  `cost` float(10,2) NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `book_stock`
--

INSERT INTO `book_stock` (`book_stock_id`, `bookid`, `branchid`, `purchasedate`, `qty`, `cost`, `status`) VALUES
(20, 12, 129, '2022-09-01', 2, 250.00, 'Active'),
(21, 13, 129, '2022-09-08', 1, 260.00, 'Active'),
(22, 14, 129, '2022-09-06', 1, 250.00, 'Active'),
(23, 15, 129, '2022-09-07', 1, 135.00, 'Active'),
(24, 16, 130, '2022-09-08', 1, 165.00, 'Active'),
(25, 17, 130, '2022-09-07', 2, 200.00, 'Active'),
(26, 21, 129, '2022-08-31', 2, 200.00, 'Active'),
(27, 20, 129, '2022-08-26', 1, 20.00, 'Active'),
(28, 19, 129, '2022-09-01', 1, 200.00, 'Active'),
(29, 18, 129, '2022-09-15', 1, 300.00, 'Active'),
(30, 24, 129, '2022-10-03', 2, 800.00, 'Active'),
(31, 23, 129, '2022-10-03', 1, 200.00, 'Active'),
(32, 22, 129, '2022-10-03', 1, 200.00, 'Active'),
(33, 26, 129, '2022-10-03', 1, 200.00, 'Active'),
(34, 25, 129, '2022-10-03', 1, 200.00, 'Active'),
(35, 30, 129, '2022-10-11', 1, 600.00, 'Active'),
(36, 17, 129, '2022-10-22', 25, 1000.00, 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `branch`
--

CREATE TABLE `branch` (
  `branchid` int(10) NOT NULL,
  `branchname` varchar(50) NOT NULL,
  `branchdescription` text NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `branch`
--

INSERT INTO `branch` (`branchid`, `branchname`, `branchdescription`, `status`) VALUES
(129, 'Health Sciences Library', 'KSAFH Main Library', 'Active'),
(130, 'BIST', 'British International School, Tabuk', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `courseid` int(10) NOT NULL,
  `branchid` int(10) NOT NULL,
  `course` varchar(50) NOT NULL,
  `coursenote` text NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`courseid`, `branchid`, `course`, `coursenote`, `status`) VALUES
(5, 130, 'BSc', 'Computer science engineering..', 'Active'),
(6, 129, 'Artificial Intelligence & Machine Learning', 'Computer Science', 'Active'),
(7, 129, 'Surgery', 'NWAFH', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `finesettings`
--

CREATE TABLE `finesettings` (
  `daytokeep` int(10) NOT NULL,
  `penaltycost` float(10,2) NOT NULL,
  `nobooks` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `finesettings`
--

INSERT INTO `finesettings` (`daytokeep`, `penaltycost`, `nobooks`) VALUES
(14, 25.00, 3);

-- --------------------------------------------------------

--
-- Table structure for table `librarian`
--

CREATE TABLE `librarian` (
  `librarian_id` int(10) NOT NULL,
  `name` varchar(25) NOT NULL,
  `type` varchar(10) NOT NULL,
  `loginid` varchar(25) NOT NULL,
  `password` varchar(100) NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `librarian`
--

INSERT INTO `librarian` (`librarian_id`, `name`, `type`, `loginid`, `password`, `status`) VALUES
(1, 'Maruan Makky', 'Admin', 'admin', 'adminadminadmin', 'Active'),
(5, 'Majed', 'Librarian', 'librarian', 'librarianlibrarianlibrarian', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `penalty`
--

CREATE TABLE `penalty` (
  `penaltyid` int(10) NOT NULL,
  `penalty_type` varchar(25) NOT NULL COMMENT 'Lost, Days',
  `transactionid` int(10) NOT NULL,
  `bookid` int(10) NOT NULL,
  `cost` float(10,2) NOT NULL,
  `penaltydate` date NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `penalty`
--

INSERT INTO `penalty` (`penaltyid`, `penalty_type`, `transactionid`, `bookid`, `cost`, `penaltydate`, `status`) VALUES
(1, '', 9, 13, 0.00, '2022-10-02', 'Active'),
(2, '', 22, 16, 0.00, '2022-10-23', 'Active'),
(3, '', 7, 13, 13.00, '2022-10-23', 'Active'),
(4, '', 12, 18, 125.00, '2022-10-23', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `studentid` int(10) NOT NULL,
  `courseid` int(10) NOT NULL,
  `studentname` varchar(25) NOT NULL,
  `studentimg` varchar(255) NOT NULL,
  `rollno` varchar(25) NOT NULL,
  `password` varchar(100) NOT NULL,
  `emailid` varchar(100) NOT NULL,
  `contactno` varchar(15) NOT NULL,
  `status` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`studentid`, `courseid`, `studentname`, `studentimg`, `rollno`, `password`, `emailid`, `contactno`, `status`) VALUES
(9, 5, 'Maruan', '811876840spider2.jpg', '10', '123', 'maruan@gmail.com', '822283', 'Active'),
(10, 5, 'Albert', '25927einstein-12923-portrait-medium.webp', '1958', '123', 'kennedy@gmail.com', '822283', 'Active'),
(11, 7, 'Ahmed albalawi', '30657ahmed.jfif', '822222', '123', 'kennedy@gmail.com', '822283', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `transationid` int(10) NOT NULL,
  `studentid` int(10) NOT NULL,
  `bookid` int(10) NOT NULL,
  `transtype` varchar(50) NOT NULL,
  `bookingdate` date NOT NULL,
  `borrowdate` datetime NOT NULL,
  `returndate` datetime NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`transationid`, `studentid`, `bookid`, `transtype`, `bookingdate`, `borrowdate`, `returndate`, `status`) VALUES
(7, 10, 13, 'Returned', '2022-09-26', '2022-09-26 11:19:00', '2022-10-23 18:47:11', 'Active'),
(8, 10, 12, 'Returned', '2022-09-26', '2022-09-26 11:33:44', '2022-09-26 11:37:37', 'Active'),
(9, 10, 13, 'Returned', '2022-10-02', '2022-10-02 11:13:56', '2022-10-02 11:31:04', 'Active'),
(12, 9, 18, 'Returned', '2022-10-04', '2022-10-04 10:56:57', '2022-10-23 19:03:52', 'Active'),
(15, 9, 19, 'Issued', '2022-10-09', '2022-10-09 09:10:24', '2022-10-24 09:10:24', 'Active'),
(17, 11, 17, 'Issued', '2022-10-11', '2022-10-11 14:40:32', '2022-10-26 14:40:32', 'Active'),
(19, 9, 12, 'Issued', '2022-10-23', '2022-10-23 12:13:33', '2022-11-07 12:13:33', 'Active'),
(28, 10, 12, 'Issued', '2022-10-23', '2022-10-23 17:36:30', '2022-11-07 17:36:30', 'Active'),
(29, 10, 17, 'Issued', '2022-10-23', '2022-10-23 17:37:53', '2022-11-07 17:37:53', 'Active'),
(30, 11, 17, 'Issued', '2022-10-23', '2022-10-23 19:03:00', '2022-11-07 19:03:00', 'Active'),
(31, 11, 14, 'Issued', '2022-10-23', '2022-10-23 19:04:36', '2022-11-07 19:04:36', 'Active');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `book`
--
ALTER TABLE `book`
  ADD PRIMARY KEY (`bookid`);
ALTER TABLE `book` ADD FULLTEXT KEY `callnumber` (`callnumber`);

--
-- Indexes for table `bookcategory`
--
ALTER TABLE `bookcategory`
  ADD PRIMARY KEY (`bookcategoryid`);

--
-- Indexes for table `book_stock`
--
ALTER TABLE `book_stock`
  ADD PRIMARY KEY (`book_stock_id`);

--
-- Indexes for table `branch`
--
ALTER TABLE `branch`
  ADD PRIMARY KEY (`branchid`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`courseid`);

--
-- Indexes for table `librarian`
--
ALTER TABLE `librarian`
  ADD PRIMARY KEY (`librarian_id`);

--
-- Indexes for table `penalty`
--
ALTER TABLE `penalty`
  ADD PRIMARY KEY (`penaltyid`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`studentid`);

--
-- Indexes for table `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`transationid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `book`
--
ALTER TABLE `book`
  MODIFY `bookid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `bookcategory`
--
ALTER TABLE `bookcategory`
  MODIFY `bookcategoryid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `book_stock`
--
ALTER TABLE `book_stock`
  MODIFY `book_stock_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `branch`
--
ALTER TABLE `branch`
  MODIFY `branchid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=131;

--
-- AUTO_INCREMENT for table `course`
--
ALTER TABLE `course`
  MODIFY `courseid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `librarian`
--
ALTER TABLE `librarian`
  MODIFY `librarian_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `penalty`
--
ALTER TABLE `penalty`
  MODIFY `penaltyid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `studentid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `transaction`
--
ALTER TABLE `transaction`
  MODIFY `transationid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
